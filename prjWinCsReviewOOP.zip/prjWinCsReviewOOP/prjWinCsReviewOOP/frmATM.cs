﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjWinCsReviewOOP
{
    public partial class frmATM : Form
    {
        public frmATM()
        {
            InitializeComponent();
        }

        private void frmATM_Load(object sender, EventArgs e)
        {
            
            this.Height = 165;
            txtDeposit.Visible = false;
            txtWithdraw.Visible = false;
            lblDeposit.Visible = false;
            lblWithdraw.Visible = false;
            
        }

        private void btnNextNumber_Click(object sender, EventArgs e)
        {
            this.Height = 260;
        }

        private void btnNextPin_Click(object sender, EventArgs e)
        {
            this.Height = 337;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Height = 460;
        }

        private void btnNextTransaction_Click(object sender, EventArgs e)
        {
            this.Height = 587;
        }

        private void btnTerminate_Click(object sender, EventArgs e)
        {
            this.Height = 165;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void radDeposit_CheckedChanged(object sender, EventArgs e)
        {
            txtDeposit.Visible = true;
            txtWithdraw.Visible = false;
            lblDeposit.Visible = true;
            lblWithdraw.Visible = false;

            txtDeposit.Focus();
        }

        private void radWithdraw_CheckedChanged(object sender, EventArgs e)
        {
            txtDeposit.Visible = false;
            txtWithdraw.Visible = true;
            lblDeposit.Visible = false;
            lblWithdraw.Visible = true;

            txtWithdraw.Focus();
        }

        private void radConsult_CheckedChanged(object sender, EventArgs e)
        {
            txtDeposit.Visible = false;
            txtWithdraw.Visible = false;
            lblDeposit.Visible = false;
            lblWithdraw.Visible = false;

            btnNextTransaction.Focus(); 
        }

        private void txtDeposit_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDeposit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsDigit(e.KeyChar) == false && char.IsControl(e.KeyChar) == false)
            {
                e.Handled = true;  // block the key for being displayed
            }
           
            
        }

        private void txtWithdraw_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) == false && char.IsControl(e.KeyChar) == false)
            {
                e.Handled = true;  // block the key for being displayed
            }
        }
    }
}

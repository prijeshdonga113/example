﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjWinCsReviewOOP
{
    public class clsTime
    {

        // Declaration of fields
        private Int32 vHour;
        private Int32 vMinute;
        private Int32 vSecond;

        // constructors
        public clsTime()
        {
            vHour = DateTime.Now.Hour;
            vMinute = DateTime.Now.Minute;
            vSecond = DateTime.Now.Second;
        }

        

        // Declaration of public properties or access methods to fields 
        public int Hour
        {   
            // access for reading
            get
            { return  vHour; }
            // access for writing
            set
            { vHour = (value >= 0 && value <= 23)? value : 0; }
        }

        public int Minute
        {
            // access for reading
            get
            { return vMinute; }
            // access for writing
            set
            { vMinute  = (value >= 0 && value <= 59) ? value : 0; }
        }

        public int Second
        {
            // access for reading
            get
            { return vSecond; }
            // access for writing
            set
            { vSecond = (value >= 0 && value <= 59) ? value : 0; }
        }
       
        // Declaration of methods
        public void Adjust(Int16 anHour, Int16 aMinute, Int16 aSecond)
        {
            if(anHour >= 0 && anHour <= 23)
            {  Hour = anHour;   }
            else {  Hour = 0;   }

            Minute = (aMinute >= 0 && aMinute < 60)? aMinute : 0;
            Second = (aSecond >= 0 && aSecond < 60) ? aSecond : 0; 
        }

        public string toUniversal()
        {
            string info;
            info = Hour + ":" + Minute + ":" + Second;
            return info;
        }

        public string toStandard()
        {
            string info;
            info = ((Hour > 12) ? Hour - 12 : Hour).ToString();
            info += ":" + Minute + ":" + Second + ((Hour > 12) ? " PM" : " AM");
            return info;
        }
    }
}

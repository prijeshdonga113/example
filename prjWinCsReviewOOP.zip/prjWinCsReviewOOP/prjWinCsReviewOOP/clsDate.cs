﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjWinCsReviewOOP
{
    public class clsDate
    {
        // fields or variables that will store the values of the properties
        private int vDay;
        private int vMonth;
        private int vYear;

        // Declaration of constructors
        public clsDate()
        {
            vDay = 1;
            vMonth = 1;
            vYear = 1;
        }

        public clsDate(int day, int month, int year)
        {
            Day = day;
            Month = month;
            Year = year;
        }

        // public properties with the getters and setters
        public int Day
        {
            // access for reading by ex: label1.Text = adate.Day
            get
            { return vDay; }
            // access for writing by ex: adate.Day = 23 
            set
            { 
                if(value >=0 && value <= 31)
                {   vDay = value;}
                else { vDay = DateTime.Today.Day; }           
            }
        }

        public int Month
        {
            // access for reading
            get
            { return vMonth; }
            // access for writing
            set
            { vMonth = (value >= 1 && value <= 12) ? value : DateTime.Today.Month; }
        }

        public int Year
        {
            // access for reading
            get
            { return vYear; }
            // access for writing
            set
            { vYear = (value >= 1 && value <= 9999) ? value : DateTime.Today.Year; }
        }

        // Public methods
        public void Initialize(int aDay, int aMonth, int aYear)
        {
            Day = aDay;
            Month =  aMonth ;
            Year = aYear;
        }

        public string ToNumber()
        {
            return Day + "/" + Month + "/" + Year;
        }

        public string ToLetter()
        {
            string info = "";
            DateTime mydate = new DateTime(Year, Month, Day);

            //  VERSION 1

            //// find the name of the day of the week 
            //int aday = Convert.ToInt32(mydate.DayOfWeek);
            //switch (aday)
            //{
            //    case 0:
            //        info = "Sunday "; break;
            //    case 1:
            //        info = "Monday "; break;
            //    case 2:
            //        info = "Tuesday "; break;
            //    case 3:
            //        info = "Wednesday "; break;
            //    case 4:
            //        info = "Thursday "; break;
            //    case 5:
            //        info = "Friday "; break;
            //    case 6:
            //        info = "Saturday "; break;
            //}

            //info += Day + " of ";

            //// find the name of the month of the year 
            //switch (Month)
            //{
            //    case 1:
            //        info += "January "; break;
            //    case 2:
            //        info += "February "; break;
            //    case 3:
            //        info += "March "; break;
            //    case 4:
            //        info += "April "; break;
            //    case 5:
            //        info += "May "; break;
            //    case 6:
            //        info += "June "; break;
            //    case 7:
            //        info += "July "; break;
            //    case 8:
            //        info += "August "; break;
            //    case 9:
            //        info += "September "; break;
            //    case 10:
            //        info += "October "; break;
            //    case 11:
            //        info += "November "; break;
            //    case 12:
            //        info += "December "; break;                
            //}

            //info += Year;

            // VERSION 2

            string[] tabDayNames = { "Sunday ", "Monday ", "Tuesday ", "Wednesday ", "Thursday ", 
                "Friday ", "Saturday " };
            int indxday = Convert.ToInt32(mydate.DayOfWeek);
           

            string[] tabMonthNames = { "January, ","February, ","March, ","April, ","May, ",
                "June, ","July, ","August, ", "September, ","October, ","November, ","December, "};

            info += tabDayNames[indxday] + Day + " of " + tabMonthNames[Month - 1] + Year;


            return info;

        }
    }
}

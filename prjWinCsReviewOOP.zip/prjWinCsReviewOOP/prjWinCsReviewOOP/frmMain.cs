﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjWinCsReviewOOP
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void mnuQuit_Click(object sender, EventArgs e)
        {
            string info = "Are you sure to want to quit this program ?";
            string title = "Application closing";

            if (MessageBox.Show(info, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void mnuATM_Click(object sender, EventArgs e)
        {
            frmATM myATM = new frmATM();
            myATM.MdiParent = this;
            myATM.Show();
        }

        private void mnuClassStruct_Click(object sender, EventArgs e)
        {
            frmClassVsStruct fc = new frmClassVsStruct();
            fc.MdiParent = this;
            fc.Show();
        }
    }
}

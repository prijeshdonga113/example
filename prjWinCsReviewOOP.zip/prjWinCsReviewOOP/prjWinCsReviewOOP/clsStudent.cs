﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjWinCsReviewOOP
{
    public class clsStudent
    {
        // ------  private fields 
        private string vName;
        private clsDate vBdate;
        private Single vGrade;

        // ------  public properties with the getters and setters
        public string Name
        {
            // access for reading 
            get { return vName; }
            // access for writing 
            set { vName = value; }
        }

        public clsDate Birthdate
        {
            // access for reading 
            get { return vBdate; }
            // access for writing 
            set { vBdate = value; }
        }

        public Single Grade
        {
            // access for reading 
            get { return vGrade; }
            // access for writing not allowed, READ ONLY property            
        }

        public int Age
        {
            // access for reading 
            get { return (DateTime.Today.Year - Birthdate.Year); }
            // access for writing not allowed, READ ONLY property
        }

        // ----  Constructors
        public clsStudent() 
        {
            Name = "Not defined";
            Birthdate = new clsDate();
            vGrade = -1;
        }

        public clsStudent(string name, int day, int month, int year, Single grade)
        {
            Name = name;
            Birthdate = new clsDate(day, month , year );
            vGrade = grade;
        }

        public clsStudent(string name,clsDate birthdate, Single grade)
        {
            Name = name;
            Birthdate = birthdate ;
            vGrade = grade;
        }

        // ------- public methods
        
        public void Register(string name, int day, int month, int year)
        {
            Name = name;
            Birthdate = new clsDate(day, month, year);
            vGrade = -1;
        }

        public bool ToGrade(Single grade)
        {
            if(grade >= 0 && grade <= 100)
            {
                vGrade = grade;
                return true;
            }
            else { return false; }
        }

        public string Display()
        {
            string info = "Name : " + Name + "\nBirthdate : " + Birthdate.ToLetter();
            info += "\nGrade : " + Grade + " /100 \nAge : " + Age + " years \n";
            return info;
        }
    }
}

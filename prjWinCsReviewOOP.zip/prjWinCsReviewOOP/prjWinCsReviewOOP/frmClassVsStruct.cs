﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjWinCsReviewOOP
{
    public partial class frmClassVsStruct : Form
    {
        private struct Time
        {
            public Int16 Hour;
            public Int16 Minute;
            public Int16 Second;
        }

        public frmClassVsStruct()
        {
            InitializeComponent();
        }

        private void frmClassVsStruct_Load(object sender, EventArgs e)
        {

            clsStudent st1 = new clsStudent();
            st1.Register("Ali Baba", 23, 11, 2000);
            MessageBox.Show(st1.Display(), "Display after register");
            st1.ToGrade(85);
            MessageBox.Show(st1.Display(), "Display after tograde(85)");
            st1.ToGrade(-5);
            MessageBox.Show(st1.Display(), "Display after tograde(-5)");

        }
    }
}
